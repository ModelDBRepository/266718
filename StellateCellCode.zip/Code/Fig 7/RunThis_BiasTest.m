%%% Saeed Farjami (McGill) 2019

%%% After running integrator, run this.

load('Itest.mat')
load('Vhold.mat')
load('late.mat')

temp = zeros(length(Vhold),1);
figure(1);
hold on

for i = 1:length(Itest)
    temp(:,1) = Itest(i);
    plot3(Vhold,temp,late(i,:),'Marker','.','MarkerSize',15,'LineStyle','none')
end
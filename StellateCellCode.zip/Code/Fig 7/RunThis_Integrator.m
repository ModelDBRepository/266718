%%% Saeed Farjami (McGill) 2019
%%% Run this code for Fig7B.

% preOpost input into the function is the lrgest Ibias.
function Integrator(preOpost)

Ibias = preOpost:-0.5:-5;
Itest = preOpost+0.01:0.5:1;
Vhold = zeros(length(Ibias),1);
late = zeros(length(Itest),length(Ibias));

root_name = 'output_';


% Set the name of the xpp file here.
odeFileName = 'Stellate_Cell_Pre.ode';

mypar = [];
for i = 1:2
    mypar(i).type = 'PAR';
    mypar(i).name = '';
    mypar(i).val = 0;
end
for i = 3:8
    mypar(i).type = 'IC';
    mypar(i).name = '';
    mypar(i).val = 0;
end
mypar(3).name = 'V';
mypar(4).name = 'h';
mypar(5).name = 'n';
mypar(6).name = 'nA';
mypar(7).name = 'hA';
mypar(8).name = 'hT';

tic
for i=1:length(Ibias)
    sol = RootSolver_Pre(Ibias(i));
    if sol.V < -90
        break;
    end
    Vhold(i,1) = double(sol.V);
    mypar(1).name = 'Ipre';
    mypar(2).name = 'Itest';
    mypar(1).val = Ibias(i);
    mypar(3).val=double(sol.V);
    mypar(4).val=double(sol.h);
    mypar(5).val=double(sol.n);
    mypar(6).val=double(sol.nA);
    mypar(7).val=double(sol.hA);
    mypar(8).val=double(sol.hT);
    for j = 1:length(Itest)
        mypar(2).val = Itest(j);
        ChangeXPPFile(odeFileName,mypar);
        RunXPP(odeFileName);
        
% Uncomment this line if you want the solutions for panel A.
%        movefile('output.dat', [root_name num2str(i)])


% Comment this if you want the solutions for panel A.
        output = load('output.dat');

        for k = 1:length(output(:,1))
            if output(k,8) > 0 && output(k+1,8)<0 && output(k,2) > -10
                plot3(mypar(3).val,Itest,output(i,1),'Marker','.','MarkerSize',20,'MarkerEdgeColor','b','MarkerFaceColor','b')
                late(j,i) = output(k,1);
                break
            end
        end
%Comment up to here.


    end
    toc
end
save('late','late');
save('Vhold','Vhold');
save('Itest','Itest');

end


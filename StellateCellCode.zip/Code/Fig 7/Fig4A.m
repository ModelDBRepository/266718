%%% After running integrator, run this to get Fig7A.

figure;
hold on
for i = 1:20
    filename = sprintf('output_%d',i);
    output = load(filename);
    output(:,14) = log2(sqrt(output(:,8).^2+output(:,9).^2+output(:,10).^2+output(:,11).^2+output(:,12).^2+output(:,13).^2));
    surface('XData', [output(:,7) output(:,7)], ...
        'YData', [output(:,5) output(:,5)], ...
        'ZData', [output(:,2) output(:,2)], ...
        'CData', [output(:,14) output(:,14)], ...
        'FaceColor', 'none', ...
        'EdgeColor', 'interp', ...
        'Marker', 'none', ...
        'LineWidth',2);
end
colorbar
view(25,5)

set(gcf,'Position',[0 100 500 800]);
set(gca,'Position',[0.06 0.11 0.92 0.87])
set(gca,...
    'FontSize',14,...
    'XLim',[0,0.11],...
    'YLim',[0,0.03],...
    'ZLim',[-60,-40])
set(gca,'TickLabelInterpreter','Latex')
set(gca,'XTick',[0 0.05 0.1]);
set(gca,'YTick',[0 0.01 0.02 0.03]);
set(gca,'ZTick',[-60 -50 -40]);
set(gca,'YTick',[0 0.05 0.1]);
set(gca,'XTickLabel',{0 0.05 0.1});
set(gca,'YTickLabel',{0 0.01 0.02 0.03});
set(gca,'ZTickLabel',{-60 -50 -40});

zlabel('Membrane Voltage (mV)','FontSize',14,'Interpreter','Latex','Position',[0.02,-0.1,-50])
ylabel('$h_{\rm A}$','FontSize',14,'Interpreter','Latex','Position',[0.12,0.016,-61])
xlabel('$h_{\rm T}$','FontSize',14,'Interpreter','Latex','Position',[0.05,0.0,-62])
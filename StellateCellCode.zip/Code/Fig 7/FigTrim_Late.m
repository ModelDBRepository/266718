function [] = FigTrim_Late()

view(40,-15)
set(gcf,'Position',[0 100 300 400]);
set(gca,'Position',[0.165 0.06 0.75 0.87])
set(gca,...
    'FontSize',14,...
    'XLim',[-90,-40],...
    'YLim',[-0.3,1.1],...
    'ZLim',[0,500])
set(gca,'TickLabelInterpreter','Latex')
set(gca,'XTick',[-80 -60 -40]);
set(gca,'YTick',[0 0.5 1]);
set(gca,'ZTick',[0 100 200 300 400 500]);
set(gca,'YTick',[0 0.5 1]);
set(gca,'XTickLabel',{-80 -60 -40});
set(gca,'ZTickLabel',{0 100 200 300 400 500});
xlabel('Holding Potential (mV)','FontSize',14,'Interpreter','Latex','Position',[-65,1.1,0],'Rotation',6)
ylabel('$I_{\rm app}$ (pA)','FontSize',14,'Interpreter','Latex','Position',[-30,0.5,0],'Rotation',-45)
zlabel('Latency (ms)','FontSize',14,'Interpreter','Latex','Position',[-30,-0.2,250])

[X,Z] = meshgrid(-90:50:-40,0:500:500);
Y=-0.206016*ones(2,2);
surf(X,Y,Z,'FaceColor','g','EdgeColor','none','facealpha',0.4)
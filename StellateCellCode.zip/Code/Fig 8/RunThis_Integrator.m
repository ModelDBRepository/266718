%%% Saeed Farjami (McGill) 2019
%%% Run this code for Fig8 (bottom).


% these rae the values for each curve.
% Pre Ibias=-0.6, -1.4 and -4.8
% Post Ibias=-0.6, -2 and -4.8

% Here you can switch between pre and post
% by (un)commenting and setting Ibias
Ibias = -1.4;
Itest1 = -0.2055:0.001:-0.15;
Itest2 = -0.15:0.01:0.1;
% Itest = -0.2058:0.0002:-0.2; % Inset post
% Itest = -0.15665:0.0002:-0.15; % Inset pre
% Itest1 = -0.156:0.001:-0.1;
% Itest2 = -0.1:0.01:0.1;
Itest = cat(2,Itest1,Itest2);
late = zeros(length(Itest),1);

% Set the name of xxp file here.
odeFileName = 'Stellate_Cell_Pre.ode';

mypar = [];
for j = 1:2
    mypar(j).type = 'PAR';
    mypar(j).name = '';
    mypar(j).val = 0;
end
for j = 3:8
    mypar(j).type = 'IC';
    mypar(j).name = '';
    mypar(j).val = 0;
end
mypar(3).name = 'V';
mypar(4).name = 'h';
mypar(5).name = 'n';
mypar(6).name = 'nA';
mypar(7).name = 'hA';
mypar(8).name = 'hT';

tic

sol = RootSolver_Pre(Ibias);
mypar(1).name = 'Ipre';
mypar(2).name = 'Itest';
mypar(1).val = Ibias;
mypar(3).val=double(sol.V);
mypar(4).val=double(sol.h);
mypar(5).val=double(sol.n);
mypar(6).val=double(sol.nA);
mypar(7).val=double(sol.hA);
mypar(8).val=double(sol.hT);
for i= 1:length(Itest)
    mypar(2).val = Itest(i);
    ChangeXPPFile(odeFileName,mypar);
    RunXPP(odeFileName);
    output = dlmread('output.dat');
    for j = 1:length(output(:,1))
        if j == length(output(:,1))
            break;
        end
        if output(j,8) > 0 && output(j+1,8) < 0 && output(j,2) > -10
    %            plot3(mypar(3).val,Itest,output0(i,1),'Marker','.','MarkerSize',20,'MarkerEdgeColor','b','MarkerFaceColor','b')
            late(i,1) = output(j,1);
            break
        end
    end
end

p1 = plot(Itest',late,'LineWidth',2);
hold on
% p2 = plot([-0.206016,-0.206016],[0,1500],'k--','LineWidth',0.5);
% p2 = plot([-0.156657,-0.156657],[0,1500],'k--','LineWidth',0.5);
% set(get(get(p2, 'Annotation'), 'LegendInformation'), 'IconDisplayStyle', 'off');

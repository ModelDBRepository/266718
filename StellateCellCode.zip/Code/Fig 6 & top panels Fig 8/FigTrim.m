%%% Makes figure ready for publication.

function [] = FigTrim()

plot([-52,-52],[100,400],'b--','LineWidth',1)
plot([-45.2,-45.2],[100,400],'k--','LineWidth',1)
box on
set(gcf,'Position',[0 100 800 300]);
set(gca,'Position',[0.06 0.11 0.92 0.87])
set(gca,...
    'FontSize',14,...
    'XLim',[-90,-40],...
    'YLim',[100,500])
set(gca,'TickLabelInterpreter','Latex')
set(gca,'XTick',[-90 -80 -70 -60 -50 -40]);
set(gca,'YTick',[100 200 300 400 500]);
set(gca,'XTickLabel',{-90 -80 -70 -60 -50 -40});
set(gca,'YTickLabel',{100 200 300 400 500});
xlabel('Membrane Holding Potential (mV)','FontSize',14,'Interpreter','Latex','Position',[-65,70])
ylabel('Latency (ms)','FontSize',14,'Interpreter','Latex','Position',[-92,300])
function roots = RootSolver_Post(Ipre)

syms V h n nA hA hT

% Parameters
gna=3.4; gk=9.0556; gleak=0.07407; gA=15.0159; gT=0.45045;
Vna=55; Vk=-80; Vleak=-38; Vca=22;

% Gating variables
mSS = 1/(1+exp((-V-44)/3));
hSS = 1/(1+exp((V+48.5)/4));
nSS = 1/(1+exp((-V-23)/5)); 
nASS = 1/(1+exp((-V-41)/13.2));
hASS = 1/(1+exp((V+96)/9.2));
mTSS = 1/(1+exp((-V-50)/3));
hTSS = 1/(1+exp((V+68)/3.75));

eqns = [Ipre-gna*mSS^3*h*(V-Vna)-gk*n^4*(V-Vk)-gleak*(V-Vleak)-gA*nA*hA*(V-Vk)-gT*mTSS*hT*(V-Vca), ...
    (hSS-h), ...
    (nSS-n), ...
    (nASS-nA), ...
    (hASS-hA), ...
    (hTSS-hT)];

if Ipre < -2
    V0 = -76;
else
    V0 = -70;
end
roots = vpasolve(eqns, V, h, n, nA, hA, hT, [V0 0.999 0.0 0.06 0.1 0.9]);

%%% Saeed Farjami (McGill) 2019
%%% Run this code for Fig6B and Fig8 (top).


% Change 'Itest' and 'Ibias'. They are different between pre and post.
Itest=-0.15;
Ibias = -0.16:-0.1:-6;
late = zeros(length(Ibias),1);

% Set the name of the xpp file here.
odeFileName = 'Stellate_Cell_Pre.ode';

mypar = [];
for i = 1:2
    mypar(i).type = 'PAR';
    mypar(i).name = '';
    mypar(i).val = 0;
end
for i = 3:8
    mypar(i).type = 'IC';
    mypar(i).name = '';
    mypar(i).val = 0;
end
mypar(3).name = 'V';
mypar(4).name = 'h';
mypar(5).name = 'n';
mypar(6).name = 'nA';
mypar(7).name = 'hA';
mypar(8).name = 'hT';

tic

for i = 1:length(Ibias)
    sol = RootSolver_Pre(Ibias(i));
    if sol.V < -90
        break;
    end
    mypar(1).name = 'Ipre';
    mypar(2).name = 'Itest';
    mypar(1).val = Ibias(i);
    mypar(2).val = Itest;
    mypar(3).val=double(sol.V);
    mypar(4).val=double(sol.h);
    mypar(5).val=double(sol.n);
    mypar(6).val=double(sol.nA);
    mypar(7).val=double(sol.hA);
    mypar(8).val=double(sol.hT);
    ChangeXPPFile(odeFileName,mypar);
    RunXPP(odeFileName);
    output0 = dlmread('output0.dat');
    
    for k = 1:length(output0(:,1))
        if output0(k,8) > 0 && output0(k+1,8)<0 && output0(k,2) > -10
            late(i,1) = output0(k,1);
            hold on
            plot(mypar(3).val,output0(k,1),'Marker','.','MarkerSize',20,'MarkerEdgeColor','b','MarkerFaceColor','b')
            break
        end
    end
end

toc

FigTrim();
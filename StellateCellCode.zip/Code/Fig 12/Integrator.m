function late = Integrator(mypar)

% Set the name of xpp file here.
odeFileName = 'Stellate_Cell_Post.ode';

ChangeXPPFile(odeFileName,mypar);
RunXPP(odeFileName);

output=dlmread('output0.dat');

for i = 1:length(output(:,1))
    if i == length(output(:,1))
        late = Inf;
        return
    end
    if output(i,8) > 0 && output(i+1,8)<0 && output(i,2) > -10
        late = output(i,1);
        return;
    end
end

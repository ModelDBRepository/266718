%%% Saeed Farjami (McGill) 2019
%%% Run this code for Fig12.

ginh = 0:0.02:5;
gexc = 0:0.02:5;
excsize = length(ginh);
inhsize = length(gexc);
heat = zeros(excsize,inhsize);

mypar = [];
for i = 1:2
    mypar(i).type = 'PAR';
    mypar(i).name = '';
    mypar(i).val = 0;
end

for i = 1:length(ginh)
    tic
    mypar(1).name = 'ginh';
    for j = 1:length(gexc)
        mypar(2).name = 'gexc';
        mypar(1).val = ginh(i);
        mypar(2).val = gexc(j);
        heat(i,j) = Integrator(mypar);
    end
    toc
end
imagesc(heat)
colorbar
view(0,-90)

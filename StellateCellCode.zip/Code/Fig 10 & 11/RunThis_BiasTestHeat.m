%%% Saeed Farjami (McGill) 2019
%%% Run this code for Figs 10 and 11A.


% Here you can switch between pre and post
% by (un)commenting Ibias and Itest to switch between pre and post.
Ibias = -0.206017:-0.01:-5; % post
Itest = -0.207:0.00003:-0.2; % post

% Ibias = -0.1567:-0.01:-5; % pre
% Itest = -0.17:0.0003:-0.1; % pre
biassize = length(Ibias);
testsize = length(Itest);
heat = zeros(biassize,testsize);

% Set the name of xxp file here.
odeFileName = 'Stellate_Cell_Post.ode';

mypar = [];
for i = 1:2
    mypar(i).type = 'PAR';
    mypar(i).name = '';
    mypar(i).val = 0;
end
for i = 3:8
    mypar(i).type = 'IC';
    mypar(i).name = '';
    mypar(i).val = 0;
end
mypar(3).name = 'V';
mypar(4).name = 'h';
mypar(5).name = 'n';
mypar(6).name = 'nA';
mypar(7).name = 'hA';
mypar(8).name = 'hT';

for i = 1:length(Ibias)
    tic
    sol = RootSolver_Post(Ibias(i)); % to be changed
    mypar(3).val=double(sol.V);
    mypar(4).val=double(sol.h);
    mypar(5).val=double(sol.n);
    mypar(6).val=double(sol.nA);
    mypar(7).val=double(sol.hA);
    mypar(8).val=double(sol.hT);
    for j = 1:length(Itest)
        mypar(1).name = 'Ipre';
        mypar(2).name = 'Itest';
        mypar(1).val = Ibias(i);
        mypar(2).val = Itest(j);
        heat(i,j) = Integrator(mypar);
    end
    toc
end
imagesc(heat)
colorbar
view(0,-90)

function dydt = RHS_Pre(t,y,Ipre,Itest)

sympref('HeavisideAtOrigin',0);
V=y(1); h=y(2); n=y(3); nA=y(4); hA=y(5); hT=y(6);
dydt = zeros(6,1);

% Parameters
C=1.50148;
gna=3.4; gk=9.0556; gleak=0.07407; gA=15.0159; gT=0.45045;
Vna=55; Vk=-80; Vleak=-38; Vca=22;
y0=0.1; A=322; w=46; Vc=-74;

% Gating variables
mSS = 1/(1+exp((-V-37)/3));
hSS = 1/(1+exp((V+40)/4));
nSS = 1/(1+exp((-V-23)/5)); 
nASS = 1/(1+exp((-V-27)/13.2));
hASS = 1/(1+exp((V+80)/6.5));
mTSS = 1/(1+exp((-V-50)/3));
hTSS = 1/(1+exp((V+68)/3.75));

% Time scales
tauh = y0 + (2*A*w)/(4*pi*(V-Vc)^2+w^2);
taun = 6/(1+exp((V+23)/15));
dydt(1) = (Ipre*heaviside(-t)+Itest*heaviside(t)-gna*mSS^3*h*(V-Vna)-gk*n^4*(V-Vk) ...
           -gleak*(V-Vleak)-gA*nA*hA*(V-Vk)-gT*mTSS*hT*(V-Vca))/C;
dydt(2) = (hSS-h)/tauh;
dydt(3) = (nSS-n)/taun;
dydt(4) = (nASS-nA)/5;
dydt(5) = (hASS-hA)/10;
dydt(6) = (hTSS-hT)/15;

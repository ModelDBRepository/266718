function late = Integrator(mypar)

odeFileName = 'Stellate_Cell_Post.ode';

ChangeXPPFile(odeFileName,mypar);
RunXPP(odeFileName);
%load 'output0.dat';
output0=dlmread('output0.dat');

for i = 1:length(output0(:,1))
    if i == length(output0(:,1))
        late = Inf;
        return
    end
    if output0(i,8) > 0 && output0(i+1,8)<0 && output0(i,2) > -10
        late = output0(i,1);
        return
    end
end
